package softuniBlog.controller;

/**
 * Created by Antoan on 12.04.2017.
 */
public @interface PreAutorize {
}
